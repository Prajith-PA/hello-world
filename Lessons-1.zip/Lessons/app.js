var rpn = require('./rpn/lib/rpn');
console.log(rpn.compute([1,2,3,'+','-']));