'use strict';

var http = require('http');
var qs = require('querystring');

var form_data ='';

http.createServer(function(req,res){
    req.on('readable',function(){
        console.log('I from the readeable event');
        var d = req.read();
        if(typeof d == 'string') {
            form_data += d;
        } else if(typeof d == 'object' && d instanceof Buffer) {
            form_data += d.toString('utf8');
        }
    });

    req.on('end',function() {
        console.log('I from the end event');
        var out;
        if(!form_data) {
            out = 'Invalid Json data';
        } else {
            var obj = qs.parse(form_data);
            if(!obj) {
                out = 'Error Parsing Form data';
            } else {
                out = 'Valid form post' + JSON.stringify(obj);
            }
        }
        console.log('Before sending response');
        res.end(out);
    })
}).listen(3050);