'use strict';

var http = require('http');
var fs = require('fs');
var url = require('url');
var path = require('path');

/* URL

/album.json
/albums/can.json
/content/test.html
/template/file.html
/page/home

*/

http.createServer(function(req,res){
    req.parsed_url = url.parse(req.url,true);
    req.fullUrl = req.parsed_url.pathname;
    console.log(req.fullUrl.substring(0,6));
    if(req.fullUrl.substring(0,6) == '/page/') {
        var fname = req.fullUrl.substring(6);
        console.log(fname);
        fs.readFile('./template/' + fname + '.html','utf8',function(err,data) {
            console.log(err);
            if(err) {
                res.writeHead(503,{"Content-Type" : "text/html"});
                res.end("Invalid Content");
                return;
            }
            res.writeHead(200,{"Content-Type" : "text/html"});
            res.end(data.replace('{{PNAME}}',fname));

        });


    } else if(req.fullUrl.substring(0,9) == '/content/') {
        var page = req.fullUrl.substring(9);
        var rs = fs.createReadStream('./content/'+page);
        res.writeHead(200,{"Content-Type" : getextention(page) });
        rs.on('readable',function(){
            var cont = rs.read();
            if(typeof cont == 'string') {
                res.write(cont)
            } else if (typeof cont == 'object' && cont instanceof Buffer) {
                if(getextention(page).substring(0,6) == 'image/') {
                    res.write(cont);
                } else {
                    res.write(cont.toString('utf8'));
                }
            }
        });
        rs.on('end',function(){
            res.end();
        });
        rs.on('error',function(){
            res.writeHead(404,{'Content-Type':'application/json'});
            res.write(JSON.stringify({error:"file not found",message:"file not found"}))
        })

        
    } else if(req.fullUrl == '/album.json') {
        loadAlbums(function(err,data){
        if(err != null) {
            res.writeHead(503,{"Content-Type" : "application/json" });
            res.end(JSON.stringify({error : err.message}) + '\n');
            return;
        }
        res.writeHead(200,{"Content-Type" : "application/json" });
        res.end(JSON.stringify({error : null, data : {album : data}}) + '\n');
        });
    } else if(req.fullUrl.substring(0,6) == '/album' && req.fullUrl.substring(req.fullUrl.length-5) == '.json' ){
        var albumUrl = req.fullUrl.substring(7,req.fullUrl.length-5);
        var page = isNaN(req.parsed_url.query.page)? 0 : req.parsed_url.query.page;
        var page_size = isNaN(req.parsed_url.query.page_size)? 0 : req.parsed_url.query.page_size;
        loadAlbumsFiles(function(err,data){
        if(err != null) {
            res.writeHead(503,{"Content-Type" : "application/json" });
            res.end(JSON.stringify({error : err.message}) + '\n');
            return;
        }
        res.writeHead(200,{"Content-Type" : "application/json" });
        res.end(JSON.stringify({error : null, data : {Album : albumUrl, Files : data}}) + '\n');
        },albumUrl,page,page_size);
    } else  {
        res.writeHead(200,{
            "Content-Type" : "application/json"
        });
        res.end(JSON.stringify({error : "unknown_resource", message : "From the unknown resource"}) + '\n');
    }
}).listen(3030);

function loadAlbums(callback) {
    fs.readdir('albums/',function(err,file_list){
        if(err) {
            callback(err);
            return;
        }
        var outputarr = [];
        (function fnIterator(index){
          if(index == file_list.length) {
              callback(null,outputarr);
              return;
          }
          fs.stat('albums/' + file_list[index],function(err,stats){
            if(err) {
                callback(err);
                return;
            }
            if(stats.isDirectory()){
                outputarr.push(file_list[index]);
            }
            fnIterator(index + 1);
          })
        })(0);
    })
}

function loadAlbumsFiles(callback,albumUrl,page,page_size) {
    fs.readdir('albums/' + albumUrl +'/',function(err,files){
        if(err) {
            callback(err);
            return;
        }
        var outputarr = [];
        (function fnFileIterator(index){
          if(index == files.length) {
              var photos = outputarr.splice(page * page_size,page_size);
              callback(null,photos);
              return;
          }
          fs.stat('albums/' + albumUrl +'/'+ files[index],function(err,stats){
            if(err) {
                callback(err);
                return;
            }
            if(stats.isFile()){
                outputarr.push(files[index]);
            }
            fnFileIterator(index + 1);
          })
        })(0);
    })
}

function loadDiir(callback) {
    fs.readdir('albums/',function(err,file_list){
        if(err) {
            callback(err);
            return;
        }
        var outputarr = [];
        (function fnIterator(index){
          if(index == file_list.length) {
              callback(null,outputarr);
              return;
          }
          fs.stat('albums/' + file_list[index],function(err,stats){
            if(err) {
                callback(err);
                return;
            }
            if(stats.isDirectory()){
                outputarr.push(file_list[index]);
            }
            fnIterator(index + 1);
          })
        })(0);
    })
}
function getextention(filename){
    var ext = path.extname(filename);
    switch(ext) {
        case 'jpeg' : case 'jpg' :
            return 'image/jpeg';
        case 'gif' : 
            return 'image/gif';
        case 'png' :
            return 'image/png';
        case 'js' :
            return 'text/javascript';
        case 'css' :
            return 'text/css'
        case 'html' :
            return 'text/html';
        default :
            return 'text/plian';

    }
}

/*
var server = http.createServer();

server.on('request',function(req,res){
    res.writeHead(200,{
        "Content-Type" : "application\json"
    });
    res.end(JSON.stringify({error : null}));
});

server.listen(3030);

*/