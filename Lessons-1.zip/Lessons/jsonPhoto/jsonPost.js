'use strict';

var http = require('http');

var json_data ='';

http.createServer(function(req,res){
    req.on('readable',function(){
        console.log('I from the readeable event');
        var d = req.read();
        if(typeof d == 'string') {
            json_data += d;
        } else if(typeof d == 'object' && d instanceof Buffer) {
            json_data += d.toString('utf8');
        }
    });

    req.on('end',function() {
        console.log('I from the end event');
        var out;
        if(!json_data) {
            out = 'Invalid Json data';
        } else {
            var json;
            try {
                console.log('Before parsing ', json_data);
                json = JSON.parse(json_data);
            } catch(e) {

            }
            if(!json) {
                out = 'JSON processing error';
            } else {
                out = 'Valid JSON ' + json_data;
            }
        }
        console.log('Before sending response');
        res.end(out);
    })
}).listen(3040);