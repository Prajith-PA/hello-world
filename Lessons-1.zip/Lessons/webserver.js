var http = require('http');

http.createServer(function(req,res){
    res.end('This is from the nodeserver');
}).listen(3030);